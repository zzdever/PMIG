var class_panel_frame =
[
    [ "PanelFrame", "class_panel_frame.html#a97621fde3eec751c0834c9227e4dc782", null ],
    [ "paintEvent", "class_panel_frame.html#a7a86a1868ab50fc9ec5f0717d7a9cc2f", null ]
];