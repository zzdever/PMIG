var class_lasso_tool_function =
[
    [ "LassoToolFunction", "class_lasso_tool_function.html#ae6d52aec5bc8754d26c6eef37c1c6b08", null ],
    [ "getMagnetic", "class_lasso_tool_function.html#a5a463c428829f05f7e621e095073b36a", null ]
];