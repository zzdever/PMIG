var searchData=
[
  ['gaussianblur',['gaussianBlur',['../class_scribble_area.html#a5b5545e0f7fbc6b6ee901fac13830a6e',1,'ScribbleArea']]],
  ['grabcutfilter',['grabcutFilter',['../class_scribble_area.html#ab132e409c1e8932133c914413d498453',1,'ScribbleArea']]]
];
