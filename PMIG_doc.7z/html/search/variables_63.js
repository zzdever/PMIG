var searchData=
[
  ['centerscribblearea',['centerScribbleArea',['../class_main_window.html#a44434663ccd61028e1ba78fe0f4ec264',1,'MainWindow']]],
  ['currentimagenum',['currentImageNum',['../class_scribble_area.html#a809a8b32901909090d6c8b3a065d2e1a',1,'ScribbleArea']]],
  ['currenttooltype',['currentToolType',['../class_main_window.html#a9cfe88d5c2223d2496261fc58510894e',1,'MainWindow']]]
];
