var searchData=
[
  ['bgcolor',['bgColor',['../class_scribble_area.html#aa8a7c29726dbb37ce684ca9fc7909c22',1,'ScribbleArea']]],
  ['brushtoolfunction',['brushToolFunction',['../class_scribble_area.html#a88a7c7603f2aff5c5edab76f4b0544df',1,'ScribbleArea']]]
];
