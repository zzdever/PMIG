var searchData=
[
  ['opencvprocess_2ecpp',['opencvprocess.cpp',['../opencvprocess_8cpp.html',1,'']]],
  ['openfile',['openFile',['../class_main_window.html#a288b768c3c21a9171bdc56fe845ece8b',1,'MainWindow']]],
  ['openimage',['openImage',['../class_scribble_area.html#afdce32fa1f5d3220987d4983e8a43e1e',1,'ScribbleArea']]],
  ['originalimage',['originalImage',['../class_scribble_area.html#ac96cf279648736de319bfaaefc9e0651',1,'ScribbleArea']]],
  ['originalimagesaved',['originalImageSaved',['../class_scribble_area.html#a17de7460ded6c97171a378dbfd678782',1,'ScribbleArea']]]
];
