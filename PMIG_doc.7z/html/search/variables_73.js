var searchData=
[
  ['selectiontype',['selectionType',['../class_scribble_area.html#abf5d4fa7daed7fcb37b065777d3ffe14',1,'ScribbleArea']]],
  ['somethingselected',['somethingSelected',['../class_scribble_area.html#a12f1cd8e723005ff52a2a326601b5eba',1,'ScribbleArea']]]
];
