var searchData=
[
  ['windowwidgetaction',['windowWidgetAction',['../class_panel.html#a7cec1adf679cf975fea3ab55eb16abe0',1,'Panel']]],
  ['windowwidgetmenu',['windowWidgetMenu',['../class_main_window.html#ad2e56c8858af1838988707de1b8cc94c',1,'MainWindow']]]
];
