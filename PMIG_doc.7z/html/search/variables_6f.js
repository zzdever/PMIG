var searchData=
[
  ['originalimage',['originalImage',['../class_scribble_area.html#ac96cf279648736de319bfaaefc9e0651',1,'ScribbleArea']]],
  ['originalimagesaved',['originalImageSaved',['../class_scribble_area.html#a17de7460ded6c97171a378dbfd678782',1,'ScribbleArea']]]
];
