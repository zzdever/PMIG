var searchData=
[
  ['keypressevent',['keyPressEvent',['../class_scribble_area.html#a3ed554609fd0eb635760ab75abe81479',1,'ScribbleArea']]]
];
