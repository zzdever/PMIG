var searchData=
[
  ['id',['id',['../class_color_icon_action.html#a11d799bf0358f7a23d4dcf6260612d5c',1,'ColorIconAction']]],
  ['imagecentralpoint',['imageCentralPoint',['../class_scribble_area.html#a4a891f27abee231c9350f5f9716b3bac',1,'ScribbleArea']]],
  ['imagestackdisplay',['imageStackDisplay',['../class_scribble_area.html#aa85c8b4f52b0dafbe1a984b6b31dc1e0',1,'ScribbleArea']]],
  ['imagestackedit',['imageStackEdit',['../class_scribble_area.html#af18cd04d44815ed0817d22c69f41e21b',1,'ScribbleArea']]],
  ['irregularselectionpointnum',['irregularSelectionPointNum',['../class_scribble_area.html#a76ce89a60b0f86056f4a3650061e3c2c',1,'ScribbleArea']]],
  ['irregularselectionpoints',['irregularSelectionPoints',['../class_scribble_area.html#a3baeaf275d8377638899359f5a4cbec0',1,'ScribbleArea']]],
  ['ismousemoving',['isMouseMoving',['../class_scribble_area.html#a82dd61681481335c5b02eff90e4afa73',1,'ScribbleArea']]],
  ['ismousepressed',['isMousePressed',['../class_scribble_area.html#a4ff3d063bff73b9dc1e5dba28ba1c092',1,'ScribbleArea']]]
];
