var searchData=
[
  ['ipl2mat',['Ipl2Mat',['../class_scribble_area.html#a539a9876d2b8964ce16e1e029dbf7fe7',1,'ScribbleArea']]],
  ['iplimage2qimage',['IplImage2QImage',['../class_scribble_area.html#a95cb8fd4aef653568a19addbb4b2b892',1,'ScribbleArea']]],
  ['ismodified',['isModified',['../class_scribble_area.html#a39eccfe97fab1b788cc873d5de7fce46',1,'ScribbleArea']]]
];
