var searchData=
[
  ['openfile',['openFile',['../class_main_window.html#a288b768c3c21a9171bdc56fe845ece8b',1,'MainWindow']]],
  ['openimage',['openImage',['../class_scribble_area.html#afdce32fa1f5d3220987d4983e8a43e1e',1,'ScribbleArea']]]
];
