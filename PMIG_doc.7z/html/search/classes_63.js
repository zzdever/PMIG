var searchData=
[
  ['coloriconaction',['ColorIconAction',['../class_color_icon_action.html',1,'']]]
];
