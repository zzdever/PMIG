var searchData=
[
  ['blackandwhite',['blackAndWhite',['../class_scribble_area.html#a0c33d7376960578c2cc39d9bfb153ad2',1,'ScribbleArea']]],
  ['brushtoolfunction',['BrushToolFunction',['../class_brush_tool_function.html#aa1cb6986ab30ae64128002c692d4290f',1,'BrushToolFunction']]],
  ['brushtooltweak',['BrushToolTweak',['../class_brush_tool_tweak.html#aeed0fc50628c810b5a01ace5f28d50d7',1,'BrushToolTweak']]]
];
