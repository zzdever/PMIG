var searchData=
[
  ['cannyedge',['cannyEdge',['../class_scribble_area.html#aff9034e3ddaae1296a3aab8fdb30fd30',1,'ScribbleArea']]],
  ['clearpoints',['clearPoints',['../class_pen_tool_function.html#ad429ee478c88fbe6fcde019697cef33a',1,'PenToolFunction']]],
  ['closeevent',['closeEvent',['../class_main_window.html#a4e20a4a065fbb0e4d3532a45a0a91425',1,'MainWindow']]],
  ['coloriconaction',['ColorIconAction',['../class_color_icon_action.html#aabc8d51f340cf2681ada53e6533484fb',1,'ColorIconAction']]],
  ['contextmenuevent',['contextMenuEvent',['../class_scribble_area.html#ace1abdc60eb03298dbcc1de3833bd80a',1,'ScribbleArea']]]
];
