var searchData=
[
  ['cannyedge',['cannyEdge',['../class_scribble_area.html#aff9034e3ddaae1296a3aab8fdb30fd30',1,'ScribbleArea']]],
  ['centerscribblearea',['centerScribbleArea',['../class_main_window.html#a44434663ccd61028e1ba78fe0f4ec264',1,'MainWindow']]],
  ['clearpoints',['clearPoints',['../class_pen_tool_function.html#ad429ee478c88fbe6fcde019697cef33a',1,'PenToolFunction']]],
  ['closeevent',['closeEvent',['../class_main_window.html#a4e20a4a065fbb0e4d3532a45a0a91425',1,'MainWindow']]],
  ['coloriconaction',['ColorIconAction',['../class_color_icon_action.html',1,'ColorIconAction'],['../class_color_icon_action.html#aabc8d51f340cf2681ada53e6533484fb',1,'ColorIconAction::ColorIconAction()']]],
  ['contextmenuevent',['contextMenuEvent',['../class_scribble_area.html#ace1abdc60eb03298dbcc1de3833bd80a',1,'ScribbleArea']]],
  ['currentimagenum',['currentImageNum',['../class_scribble_area.html#a809a8b32901909090d6c8b3a065d2e1a',1,'ScribbleArea']]],
  ['currenttooltype',['currentToolType',['../class_main_window.html#a9cfe88d5c2223d2496261fc58510894e',1,'MainWindow']]]
];
