var searchData=
[
  ['about',['about',['../class_main_window.html#a7be6a5d98970ac1a6296c6f9aee1e9bb',1,'MainWindow']]],
  ['applytoolfunction',['ApplyToolFunction',['../class_scribble_area.html#a0c9f70e3ce6d57c25dd641cb7e14bb38',1,'ScribbleArea::ApplyToolFunction(QPoint lastPoint, QPoint currentPoint)'],['../class_scribble_area.html#ae4e8671f48893ab00eefbf2b6e843621',1,'ScribbleArea::ApplyToolFunction(QPoint currentPoint)'],['../class_scribble_area.html#a42255c7a44479e447a43bf26e7a89822',1,'ScribbleArea::ApplyToolFunction()']]]
];
