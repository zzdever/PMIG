var searchData=
[
  ['mainwindow',['MainWindow',['../class_main_window.html#a8b244be8b7b7db1b08de2a2acb9409db',1,'MainWindow']]],
  ['makeselection',['makeSelection',['../class_scribble_area.html#a1df2c552892d9d8c3e5e5f04f33f5610',1,'ScribbleArea']]],
  ['makeselection_5f',['makeSelection_',['../class_pen_tool_function.html#a376d66abbc37a08aed0873c8bcb53c95',1,'PenToolFunction']]],
  ['marqueetoolfunction',['MarqueeToolFunction',['../class_marquee_tool_function.html#a323f617feb6f5d0f3184855566856610',1,'MarqueeToolFunction']]],
  ['marqueetooltweak',['MarqueeToolTweak',['../class_marquee_tool_tweak.html#ac05c2e399fc62162142b43d3bcef605a',1,'MarqueeToolTweak']]],
  ['mat2ipl',['Mat2Ipl',['../class_scribble_area.html#a1edfb51526bc5ca5d8e0c469ef65526b',1,'ScribbleArea']]],
  ['maybesave',['maybeSave',['../class_main_window.html#a44eb5d77b382a5acd4b0091f499f4352',1,'MainWindow']]],
  ['mousemoveevent',['mouseMoveEvent',['../class_scribble_area.html#ae98981b6c07de07afdc39d57810e945b',1,'ScribbleArea']]],
  ['mousepressevent',['mousePressEvent',['../class_scribble_area.html#a7646e72c61ec6a1eeda468fb6dfa66f1',1,'ScribbleArea']]],
  ['mousereleaseevent',['mouseReleaseEvent',['../class_scribble_area.html#a991eb6ab4ac21895973bc9d81b84a30e',1,'ScribbleArea']]]
];
