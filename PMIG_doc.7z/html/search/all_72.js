var searchData=
[
  ['readjustrect',['readjustRect',['../class_scribble_area.html#a996cc386cdbc703c0a4cde902b1c8f77',1,'ScribbleArea']]],
  ['resizeevent',['resizeEvent',['../class_panel.html#a13590989b1112324d983fdc957503d40',1,'Panel::resizeEvent()'],['../class_scribble_area.html#aaf6be24625a5f0fe1e4a3b8eecb07575',1,'ScribbleArea::resizeEvent()']]],
  ['resizeimage',['resizeImage',['../class_scribble_area.html#af968a1bb4a81acf6a2462fd3ecb7c725',1,'ScribbleArea']]],
  ['rotateimage2',['rotateImage2',['../class_scribble_area.html#a5fe71b9e739c5e2fcd873e176ea0288a',1,'ScribbleArea']]],
  ['rotateselectedarea',['rotateSelectedArea',['../class_scribble_area.html#a49b5f494e1711b5605042cf3a68f4b0b',1,'ScribbleArea']]]
];
