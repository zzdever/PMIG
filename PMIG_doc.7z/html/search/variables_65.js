var searchData=
[
  ['erasetoolfunction',['eraseToolFunction',['../class_scribble_area.html#a3efd372c19dce7eba4716fc21308a56c',1,'ScribbleArea']]]
];
