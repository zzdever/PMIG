var class_marquee_tool_tweak =
[
    [ "MarqueeToolTweak", "class_marquee_tool_tweak.html#ac05c2e399fc62162142b43d3bcef605a", null ],
    [ "setSelectionType", "class_marquee_tool_tweak.html#a4744c14b2fc2026807587e820fd9d58c", null ]
];