var class_panel =
[
    [ "Panel", "class_panel.html#a331e104d71e561fb2721ca23858703c8", null ],
    [ "resizeEvent", "class_panel.html#a13590989b1112324d983fdc957503d40", null ],
    [ "menu", "class_panel.html#aaf34d89c539e711615f3bbb9a8c6e369", null ],
    [ "windowWidgetAction", "class_panel.html#a7cec1adf679cf975fea3ab55eb16abe0", null ]
];