var class_tool_type =
[
    [ "toolType", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598", [
      [ "Brush", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598aa276790ebb0a75536a42823ae99dd7a8", null ],
      [ "Erase", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598a88269273e86adce9953d60fc8ca85959", null ],
      [ "Marquee", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598aef4f2de93d18ab37745c25ad0148d072", null ],
      [ "Pen", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598a02e89e70ccaabbbcad82348212be025f", null ],
      [ "Transform", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598a945c4e5468d86644c03b3c3ca422c241", null ],
      [ "Lasso", "class_tool_type.html#a49dfe40d6fce6141c2b415f43024a598a23992a2aa0d30313df9523c8b44c768e", null ]
    ] ]
];