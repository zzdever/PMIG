var class_erase_tool_function =
[
    [ "EraseToolFunction", "class_erase_tool_function.html#ae8be235ad017c706c4ec7c01aa01fd0d", null ],
    [ "getEraseShape", "class_erase_tool_function.html#aebfa0e968e37a66f94c5843611193372", null ],
    [ "getEraseSize", "class_erase_tool_function.html#acdee509cf5d65cdcf98aa0aa29ab22cc", null ]
];