var files =
[
    [ "mainwindow.cpp", "mainwindow_8cpp.html", "mainwindow_8cpp" ],
    [ "mainwindow.h", "mainwindow_8h_source.html", null ],
    [ "opencvprocess.cpp", "opencvprocess_8cpp.html", null ],
    [ "panels.cpp", "panels_8cpp.html", "panels_8cpp" ],
    [ "panels.h", "panels_8h_source.html", null ],
    [ "scribblearea.cpp", "scribblearea_8cpp.html", null ],
    [ "scribblearea.h", "scribblearea_8h_source.html", null ],
    [ "toolbox.cpp", "toolbox_8cpp.html", null ],
    [ "toolbox.h", "toolbox_8h_source.html", null ]
];