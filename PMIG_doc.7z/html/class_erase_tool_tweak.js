var class_erase_tool_tweak =
[
    [ "EraseToolTweak", "class_erase_tool_tweak.html#a1c1c6c445c395c567c39ef36e2449646", null ],
    [ "setEraseShape", "class_erase_tool_tweak.html#a3a8e5f876f0f2af9945b12282b176b1b", null ],
    [ "setEraseSize", "class_erase_tool_tweak.html#aeb4d867c8141a6bda091389aa8b321ac", null ]
];