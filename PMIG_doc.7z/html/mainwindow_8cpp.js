var mainwindow_8cpp =
[
    [ "ColorIconAction", "class_color_icon_action.html", "class_color_icon_action" ],
    [ "TILE_SIZE", "mainwindow_8cpp.html#a62ecd70800687eb2d625af180c4210d7", null ]
];