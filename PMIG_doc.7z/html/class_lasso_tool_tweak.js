var class_lasso_tool_tweak =
[
    [ "LassoToolTweak", "class_lasso_tool_tweak.html#a33e417e8efd7a9637853ae66cc25f5a7", null ],
    [ "setMagnetic", "class_lasso_tool_tweak.html#a7b6976497cca9fdb6115703d7cf1b95d", null ]
];