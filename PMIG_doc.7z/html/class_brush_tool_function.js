var class_brush_tool_function =
[
    [ "BrushToolFunction", "class_brush_tool_function.html#aa1cb6986ab30ae64128002c692d4290f", null ],
    [ "getAntiAliasing", "class_brush_tool_function.html#a0665bc3c2c304b5889629680912484a5", null ],
    [ "getBrushSize", "class_brush_tool_function.html#a827a6a848f2246a63f58f876b950d0cf", null ],
    [ "getLineType", "class_brush_tool_function.html#a49319b286a0b4a9f7e093963ac123b26", null ]
];