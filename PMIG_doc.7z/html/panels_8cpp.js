var panels_8cpp =
[
    [ "PANEL_IMPLEMENTED", "panels_8cpp.html#afedded9e6508a989622ab15eb8424388", null ]
];