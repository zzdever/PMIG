var class_brush_tool_tweak =
[
    [ "BrushToolTweak", "class_brush_tool_tweak.html#aeed0fc50628c810b5a01ace5f28d50d7", null ],
    [ "setAntiAliasing", "class_brush_tool_tweak.html#a59c4feb8a84f449004e9d30370e90824", null ],
    [ "setBrushSize", "class_brush_tool_tweak.html#aa2f0eabb114bd2f9036b3bcd793258fa", null ],
    [ "setLineType", "class_brush_tool_tweak.html#ab42703fcf2c6ac2ecf7c60180f1b8c8a", null ]
];