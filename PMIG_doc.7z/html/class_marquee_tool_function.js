var class_marquee_tool_function =
[
    [ "MarqueeToolFunction", "class_marquee_tool_function.html#a323f617feb6f5d0f3184855566856610", null ],
    [ "getSelectionType", "class_marquee_tool_function.html#a56c0c5d191a8139627b4ccaf1d44bf9f", null ]
];