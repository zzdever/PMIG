var class_color_icon_action =
[
    [ "ColorIconAction", "class_color_icon_action.html#aabc8d51f340cf2681ada53e6533484fb", null ],
    [ "updateColorIcon", "class_color_icon_action.html#ae1e19112ea77d9b530119ca8f5b9df1b", null ],
    [ "id", "class_color_icon_action.html#a11d799bf0358f7a23d4dcf6260612d5c", null ]
];